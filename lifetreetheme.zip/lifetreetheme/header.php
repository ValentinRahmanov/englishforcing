<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Древо Жизни</title>
    <link href="<?php bloginfo ('stylesheet_url'); ?>" rel="stylesheet">
	<?php wp_head();?>
</head>
<body>
	<?bloginfo('stylesheet');?>
<container class="main">
    <header>
       <ul>
           <li>
            <figure class="won">
             <img src="<?php bloginfo('template_url')?>/img/logo_mamatova.png">
              <img src="<?php bloginfo('template_url')?>/img/drevo_zhizni.png">
               </figure>  
           </li>
           <li>
              <figure class="kml">
              <div class="scribe1">Алексей Маматов</div>
               <img src="<?php bloginfo('template_url')?>/img/mamatov_kod_zdorovya.png" class="ggg">
               <div class="scribe2"><?php if ( is_active_sidebar( 'sidebar-4' ) ) : ?>
 
	<div id="sidebar-4" class="scribe2">
 
		<?php dynamic_sidebar( 'sidebar-4' ); ?>
 
	</div>
 
			<?php endif; ?></div>
               <div class="lokr">
               <img src="<?php bloginfo('template_url')?>/img/mamatovsign.png">
                  </div>
               </figure>
               
           </li>
       </ul>
    </header>