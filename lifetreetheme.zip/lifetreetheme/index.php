<?php get_header();?>
    <section class="po">
    <div class="lifetree1">
        <div class="add1"><p class="ml">ВИДЕОКУРС</p><br />
        <p class="sa">ПО ВОССТАНОВЛЕНИЮ ПОЗВОНОЧНИКА И СУСТАВОВ</p>
        </div>
        <div class="add2">ТРЕНИНГИ, КНИГА ПРАКТИКИ, УПРАЖНЕНИЯ, ПРОФИЛАКТИКА ЗАБОЛЕВАНИЙ</div>
    </div>
    <div class="lifetree2">
		<?php echo do_shortcode( '[contact-form-7 id="7" title="Контактная форма 1"]' ); ?>
  
         <p>Отправляя данную форму, вы соглашаетесь с политикой конфиденциальности и договором оферты.</p>
         <p>Внимание! Количество мест на трансляции ограничено! Успейте зарегистрироваться и забронировать место на бесплатной трансляции.</p> 
    </div>
        </div>
    </section>  
    <section class="general">
        <div class="lifetree3">
            <article>ПОЛЕЗНЫЕ СОВЕТЫ И ПРАКТИКИ</article>
        </div>
        <div class="l">
        <video class="gm" width="400" height="300"></video>
        </div>
        <div class="lifetree4"><article>ОТЗЫВЫ</article></div>
        <div class="d">
        <video class="mg" width="400" height="300"></video>
        </div>
    </section>
    <section class="lower">
		<div class="colonka"><div class="s1"><img src="<?php bloginfo('template_url')?>/img/predv_veshaniya.jpg"></div><p class="hr">Знакомство с авторским тренингом "Древо Жизни" Алексея Маматова</p><div class="ljh1"><p><?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
 
	<div id="sidebar-1" class="ljh1">
 
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
 
	</div>
 
			<?php endif; ?></p><button class="w1"><p>Заказать</p></button></div></div>
        <div class="blom"><div class="s2"><img src="<?php bloginfo('template_url')?>/img/kniga.jpg"></div><p class="hr">Профилактика распространенных заболеваний спины и опорно-двигательного аппарата.</p><p class="hr">Практики для восстановления и оздоровления спины и опорно-двигательного аппарата, в том числе после операций и затяжных болезней</p><div class="ljh2"><p><?php if ( is_active_sidebar( 'sidebar-2' ) ) : ?>
 
	<div id="sidebar-2" class="ljh2">
 
		<?php dynamic_sidebar( 'sidebar-2' ); ?>
 
	</div>
 
<?php endif; ?></p><button class="w2"><p>Заказать</p></button></div></div>
<div class="vb"><div class="s3"><img src="<?php bloginfo('template_url')?>/img/ekspress-kurs.jpg"></div><p class="hr">Глубокое воздействие на проблемные зоны позвоночника и самых уязвимых к паталогическим изменениям суставов. Снятие болей. Восстановление после травм.</p><div class="ljh3"><p><?php if ( is_active_sidebar( 'sidebar-3' ) ) : ?>
 
	<div id="sidebar-3" class="ljh3">
 
		<?php dynamic_sidebar( 'sidebar-3' ); ?>
 
	</div>
 
<?php endif; ?></p><button class="w3"><p>Заказать</p></button></div></div>
    </section>

<?php get_footer();?>
    