<?php
function twentynineteen_widgets_init() {

	register_sidebar(
		array(
			'name'          => __( 'Footer', 'twentynineteen' ),
			'id'            => 'sidebar-1',
			'description'   => __( 'Add widgets here to appear in your footer.', 'twentynineteen' ),
			'before_widget' => '<div class="ftr-widget">',
            'after_widget'  => '</div>',

		)
	);
	
	register_sidebar(
		array(
			'name'          => __( 'Cena-2', 'twentynineteen' ),
			'id'            => 'sidebar-2',
			'description'   => __( 'Add widgets here to appear in your footer.', 'twentynineteen' ),
			'before_widget' => '',
            'after_widget'  => '',

		)
	);
	
	register_sidebar(
		array(
			'name'          => __( 'Cena-3', 'twentynineteen' ),
			'id'            => 'sidebar-3',
			'description'   => __( 'Add widgets here to appear in your footer.', 'twentynineteen' ),
			'before_widget' => '',
            'after_widget'  => '',

		)
	);
	
	register_sidebar(
		array(
			'name'          => __( 'Position', 'twentynineteen' ),
			'id'            => 'sidebar-4',
			'description'   => __( 'Add widgets here to appear in your footer.', 'twentynineteen' ),
			'before_widget' => '',
            'after_widget'  => '',

		)
	);

}
add_action( 'widgets_init', 'twentynineteen_widgets_init' );
?>